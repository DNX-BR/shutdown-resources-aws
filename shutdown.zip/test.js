const ecs = require('./src/ecs');
const ec2 = require('./src/ec2');
const rds = require('./src/rds');
const asg = require('./src/asg');
const docdb = require('./src/docdb');
const red = require('./src/redshift');
const eks = require('./src/eks');


async function run() {

    // let event = {
    //     command: 'start',
    //     cluster: 'hml-apps',
    //     launchType: 'FARGATE',
    //     services: []
    // };
    // await ecs.StopStartECSTask(event);

    console.table(await ec2.GetAllEC2())
    console.table(await ecs.GetAllECS())
    console.table(await rds.GetAllCluster())
    console.table(await rds.GetAllInstance());
    console.table(await asg.GetAllASG());
    console.table(await docdb.GetAllDoc());
    console.table(await red.GetAllCluster());
    console.table(await eks.GetAllNodeGroups());

}

run();