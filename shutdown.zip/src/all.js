const ecs = require('./ecs');
const ec2 = require('./ec2');
const rds = require('./rds');
const asg = require('./asg');
const docdb = require('./docdb');
const red = require('./redshift');
const eks = require('./eks');

async function StartStopAllResources(event) {

    console.log("Resources: ", event.resources)

    //ASG   
    if (event.resources.filter((a) => { return a === 'ASG' }).length > 0) {
        let asgList = await asg.GetAllASG();
        for (let as of asgList) {
            as.command = event.command;
            await asg.StartStopASG(as);
        }
    }

    //ECS
    if (event.resources.filter((a) => { return a === 'ECS' }).length > 0) {
        let ecsList = await ecs.GetAllECS();
        for (let services of ecsList) {
            services.command = event.command;
            await ecs.StopStartECSTask(services);
        }
    }

    //RDS Instance
    if (event.resources.filter((a) => { return a === 'RDSnstance' }).length > 0) {
        let rdsInstanceList = await rds.GetAllInstance();
        for (let instance of rdsInstanceList) {
            instance.command = event.command;
            await rds.StartStopDbInstance(instance);
        }
    }

    //RDS Aurora
    if (event.resources.filter((a) => { return a === 'RDSAurora' }).length > 0) {
        let rdsAurora = await rds.GetAllCluster();
        for (let cluster of rdsAurora) {
            cluster.command = event.command;
            await rds.StartStopAuroraClsuter(cluster);
        }
    }

    //DocDB
    if (event.resources.filter((a) => { return a === 'DocDB' }).length > 0) {
        let docList = await docdb.GetAllDoc();
        for (let doc of docList) {
            doc.command = event.command;
            await docdb.StartStopDocdb(doc);
        }
    }


    //RedShift  
    if (event.resources.filter((a) => { return a === 'RedShift' }).length > 0) {
        let redshiftList = await red.GetAllCluster();
        for (let redshift of redshiftList) {
            redshift.command = event.command;
            await red.StartStopRedshift(event);
        }
    }


    //EKS
    if (event.resources.filter((a) => { return a === 'EKS' }).length > 0) {
        let eksList = await eks.GetAllNodeGroups();
        for (let eksCluster of eksList) {
            eksCluster.command = event.command;
            await eks.StopStartEksNodeGroup(eksCluster);
        }
    }

    //EC2
    if (event.resources.filter((a) => { return a === 'EC2' }).length > 0) {
        let ec2List = await ec2.GetAllEC2(event);
        ec2List.command = event.command;
        await ec2.StartStopEc2(ec2List);
    }

}

module.exports = {
    StartStopAllResources
}