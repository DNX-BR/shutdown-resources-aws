const aws = require('aws-sdk');

async function GetAllCluster() {
   let eventList = [];
   try {
      const redhisft = new aws.Redshift({ region: process.env.RESOURCE_REGION || 'us-east-1' });
      const clusters = await redhisft.describeClusters().promise();
      for (const cluster of clusters.Clusters) {
         eventList.push({
            ClusterIdentifier: cluster.ClusterIdentifier,
            command: '.'
         })
      }
   } catch (error) {
      console.error('Redshift GetAllCluster', error);
   }

   return eventList;
}

async function StartStopRedshift(event) {
   const redhisft = new aws.Redshift({ region: process.env.RESOURCE_REGION || 'us-east-1' });

   try {
      if (event.command === 'start') {
         await redhisft.resumeCluster({ ClusterIdentifier: event.ClusterIdentifier.trim() }).promise().
            then(() => {
               console.info(`Start Redshift ${cluster_identifier}`);
            }).catch((e) => {
               console.error(e);
            });
      } else {
         await redhisft.pauseCluster({ ClusterIdentifier: event.ClusterIdentifier.trim() }).promise().
            then(() => {
               console.info(`Stoped Redshift ${cluster_identifier}`);
            }).catch((e) => {
               console.error(e);

            });
      }
   } catch (error) {
      console.error('Redshift StartStopRedshift', error);

   }


};

module.exports = {
   StartStopRedshift,
   GetAllCluster
}