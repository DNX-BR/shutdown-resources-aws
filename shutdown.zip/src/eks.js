const aws = require('aws-sdk');

async function GetAllNodeGroups() {
    const eks = new aws.EKS({ region: process.env.RESOURCE_REGION || 'us-east-1' });
    let eventList = [];

    try {
        const eksClusters = await eks.listClusters().promise();

        for (const cluster of eksClusters.clusters) {
            eventList.push({
                cluster: cluster,
                region: process.env.RESOURCE_REGION || 'us-east-1',
                command: '.'
            });
        }

    } catch (error) {
        console.error('EKS GetAllNodeGroups:', error)
    }

    return eventList;
}

async function StopStartEksNodeGroup(event) {
    const command = event.command;
    const awsRegion = process.env.RESOURCE_REGION || 'us-east-1';
    const cluster = event.cluster;

    try {
        const ssm = new aws.SSM({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const eks = new aws.EKS({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const template = new aws.AutoScaling({ region: awsRegion });

        const nodes = await eks.listNodegroups({ clusterName: cluster }).promise();
        for (const node of nodes.nodegroups) {
            const nodeInfo = await eks.describeNodegroup({ clusterName: cluster, nodegroupName: node }).promise();
            const autoScalegroup = nodeInfo.nodegroup.resources.autoScalingGroups[0].name;

            const actualSize = nodeInfo.nodegroup.scalingConfig.desiredSize;
            const nodegroupName = nodeInfo.nodegroup.nodegroupName;

            if (command === 'start') {
                const minNode = actualSize > 0 ? nodeInfo.nodegroup.scalingConfig.minSize : await (await ssm.getParameter({ Name: `/${nodegroupName}/minNode` }).promise()).Parameter.Value;
                const maxNode = actualSize > 0 ? nodeInfo.nodegroup.scalingConfig.maxSize : await (await ssm.getParameter({ Name: `/${nodegroupName}/maxNode` }).promise()).Parameter.Value;
                const desiredNode = actualSize > 0 ? nodeInfo.nodegroup.scalingConfig.desiredSize : await (await ssm.getParameter({ Name: `/${nodegroupName}/desiredNode` }).promise()).Parameter.Value;
                await template.updateAutoScalingGroup({ AutoScalingGroupName: autoScalegroup, MaxSize: maxNode, MinSize: minNode, DesiredCapacity: desiredNode }).promise();
                console.info(`Started node group ${nodeInfo.nodegroup.nodegroupName}`)
            } else {
                await template.updateAutoScalingGroup({ AutoScalingGroupName: autoScalegroup, MaxSize: 0, MinSize: 0, DesiredCapacity: 0 }).promise();
                await ssm.putParameter({ Name: `/${nodegroupName}/minNode`, Value: `${nodeInfo.nodegroup.scalingConfig.minSize}`, Type: 'String', Overwrite: true, }).promise();
                await ssm.putParameter({ Name: `/${nodegroupName}/maxNode`, Value: `${nodeInfo.nodegroup.scalingConfig.maxSize}`, Type: 'String', Overwrite: true, }).promise();
                await ssm.putParameter({ Name: `/${nodegroupName}/desiredNode`, Value: `${nodeInfo.nodegroup.scalingConfig.desiredSize}`, Type: 'String', Overwrite: true, }).promise();
                console.info(`Stoped node group ${nodeInfo.nodegroup.nodegroupName}`);
            }
        }
    } catch (error) {
        console.error('EKS StopStartEksNodeGroup: ', error);
    }


};

module.exports = {
    StopStartEksNodeGroup, GetAllNodeGroups
}