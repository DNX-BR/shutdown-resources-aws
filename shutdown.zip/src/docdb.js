const aws = require('aws-sdk');

async function GetAllDoc() {
    let eventList = [];

    try {
        const docdb = await new aws.DocDB({ region: process.env.RESOURCE_REGION });
        const docdbs = await docdb.describeDBClusters().promise();
        for (const doc of docdbs.DBClusters) {
            eventList.push({
                DBClusterIdentifier: doc.DBClusterIdentifier,
                command: '.'
            })
        }
    } catch (error) {
        console.error('Doc GetAllDoc', error)
    }


    return eventList;
}

async function StartStopDocdb(event) {
    try {
        const docdb = await new aws.DocDB({ region: process.env.RESOURCE_REGION });
        if (event.command === 'start') {
            await docdb.startDBCluster({ DBClusterIdentifier: event.DBClusterIdentifier.trim() }).promise().
                then(() => {
                    console.info(`Start Docdb ${event.DBClusterIdentifier}`);
                }).catch((e) => {
                    console.error(e)
                });

        } else {
            await docdb.stopDBCluster({ DBClusterIdentifier: event.DBClusterIdentifier.trim() }).promise().
                then(() => {
                    console.info(`Stop Docdb ${event.DBClusterIdentifier}`);
                }).catch((e) => {
                    console.error(e)

                });
        }
    } catch (error) {
        console.error('Doc StartStopDocdb', error)

    }


}

module.exports = {
    StartStopDocdb,
    GetAllDoc
}