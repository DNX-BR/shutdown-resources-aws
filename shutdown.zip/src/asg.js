const aws = require('aws-sdk');

async function GetAllASG() {
    let eventList = [];
    try {
        const asg = await new aws.AutoScaling({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const asgs = await asg.describeAutoScalingGroups().promise();
        for (const as of asgs.AutoScalingGroups) {
            eventList.push({
                name: as.AutoScalingGroupName,
                command: '.'
            });
        }
    } catch (error) {
        console.error('ASG GetAllASG', error)
    }

    return eventList;
}

async function StartStopASG(event) {

    try {
        const numNodes = event.command === 'start' ? 1 : 0;
        const asg = await new aws.AutoScaling({ region: process.env.RESOURCE_REGION || 'us-east-1' });

        await asg.updateAutoScalingGroup({
            AutoScalingGroupName: event.name.trim(),
            DesiredCapacity: numNodes,
            MaxSize: numNodes,
            MinSize: numNodes
        }).promise().then(() => {
            console.log(`${event.command} ASG ${event.name}`)
        }).catch((e) => {
            console.error(e);
        });
    } catch (error) {
        console.error('ASG StartStopASG', error);
    }

}

// async function StartStopInstanceASG(event) {
//     const asg = new aws.AutoScaling({region: process.env.RESOURCE_REGION || 'us-east-1'});
//     await asg.enterStandby({
//         AutoScalingGroupName: event.asg,
//         InstanceIds: [event.instances]
//     }).promise();

// }

module.exports = {
    GetAllASG, StartStopASG
}