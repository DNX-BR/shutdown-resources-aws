const aws = require('aws-sdk');

async function GetAllECS() {
    let eventList = [];

    try {
        const ecs = await await new aws.ECS({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const ecsList = await ecs.listClusters().promise();

        for (const cluster of ecsList.clusterArns) {
            const services = await ecs.listServices({
                cluster: cluster,
            }).promise();

            let serv = [];
            for (const service of services.serviceArns) {
                serv.push(service.split('/')[2]);
            }
            eventList.push({
                services: serv,
                cluster: cluster,
                command: '.',
                launchType: 'FARGATE'
            });
        }
    } catch (error) {
        console.error('ECS GetAllECS', error)
    }

    return eventList;
}


async function StopStartECSTask(event) {

    try {
        const servicesInclude = event.services;
        const ecs = await new aws.ECS({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const services = await ecs.listServices({
            cluster: event.cluster,
            launchType: event.launchType,
        }).promise();

        let servicesSelected = services.serviceArns;

        if (servicesInclude.length > 0) {
            servicesSelected = servicesSelected.filter(function (s) {
                for (const includeService of servicesInclude) {
                    if (s.includes(includeService))
                        return s
                }
            });
        }

        for (const service of servicesSelected) {
            await ecs.updateService({
                cluster: event.cluster,
                service: service,
                desiredCount: event.command === 'start' ? 1 : 0
            }).promise().then(() => {
                console.info(`${event.command === 'start' ? 'Start' : 'Stop'} Task ${service}`);
            }).catch((e) => {
                console.error(e);
            });
        }
    } catch (error) {
        console.error('ECS StopStartECSTask', error)

    }

}

module.exports = {
    StopStartECSTask,
    GetAllECS
}
