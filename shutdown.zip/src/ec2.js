const aws = require('aws-sdk');

//SKIP_SCHEDULER
async function GetAllEC2(event) {
    let instanceList = [];

    try {
        const ec2 = await new aws.EC2({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const instances = await ec2.describeInstances().promise();
        for (const reservation of instances.Reservations) {
            for (const instance of reservation.Instances) {
                if ((instance.State.Name === 'running' && event.command === 'stop' && instance.InstanceLifecycle === undefined )
                    || (instance.State.Name === 'stopped' && event.command === 'start' && instance.InstanceLifecycle === undefined)) {
                    if (instance.Tags.filter((e)=> { if (e.Key === 'SKIP_SCHEDULER') return 1; }).length === 0 && instance.Tags.filter((e)=> { if (e.Key === 'aws:autoscaling:groupName') return 1; }).length === 0)
                        instanceList.push(instance.InstanceId)
                }
            }
        }
    } catch (error) {
        console.error('EC2 GetAllEC2', error);
    }

    return {
        instances: instanceList,
        command: '.'
    }
}

async function StartStopEc2(event) {
    try {
        const command = event.command;
        const instances = event.instances;
        const ec2 = await new aws.EC2({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        if (command === 'start') {
            await ec2.startInstances({ InstanceIds: instances }).promise().
                then(() => {
                    console.info(`Start instances: ${instances}`);
                }).catch((e) => {
                    console.error(e);
                });
        } else {
            await ec2.stopInstances({ InstanceIds: instances }).promise().
                then(() => {
                    console.info(`Stop instances: ${instances}`);
                }).catch((e) => {
                    console.error(e);
                });
        }
    } catch (error) {
        console.error('EC2 StartStopEc2', error);

    }

}

module.exports = {
    StartStopEc2,
    GetAllEC2
}
