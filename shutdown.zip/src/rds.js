const aws = require('aws-sdk');

async function GetAllCluster() {
    let eventList = [];
    try {
        const aurora = await new aws.RDS({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const clusters = await aurora.describeDBClusters().promise();
        for (const cluster of clusters.DBClusters) {
            eventList.push({
                DBClusterIdentifier: cluster.DBClusterIdentifier,
                command: '.'
            });
        }
    } catch (error) {
        console.error('RDS Cluster GetAllCluster', error);
    }


    return eventList;

}

async function GetAllInstance() {
    const eventList = [];

    try {
        const rds = await new aws.RDS({ region: process.env.RESOURCE_REGION || 'us-east-1' });
        const instances = await rds.describeDBInstances().promise();
        for (const instance of instances.DBInstances) {
            eventList.push({
                DBInstanceIdentifier: instance.DBInstanceIdentifier,
                command: '.'
            });
        }
    } catch (error) {
        console.error('RDS GetAllInstance', error);

    }

    return eventList;
}

async function StartStopAuroraClsuter(event) {
    const aurora = await new aws.RDS({ region: process.env.RESOURCE_REGION || 'us-east-1' });

    try {
        if (event.command === 'start') {
            await aurora.startDBCluster({ DBClusterIdentifier: event.DBClusterIdentifier }).promise()
                .then(() => {
                    console.info(`Start Aurora Cluster ${event.DBClusterIdentifier}`);
                }).catch((e) => {
                    console.error(e);
                });
        } else {
            await aurora.stopDBCluster({ DBClusterIdentifier: event.DBClusterIdentifier }).promise()
                .then(() => {
                    console.info(`Stop Aurora Cluster ${event.DBClusterIdentifier}`);
                }).catch((e) => {
                    console.error(e);
                });
        }
    } catch (error) {
        console.error('RDS StartStopAuroraClsuter', error);

    }


}

async function StartStopDbInstance(event) {
    const instance = new aws.RDS({ region: process.env.RESOURCE_REGION || 'us-east-1' });

    try {
        if (event.command === 'start') {
            await instance.startDBInstance({ DBInstanceIdentifier: event.DBInstanceIdentifier }).promise()
                .then(() => {
                    console.info(`Start Instance ${event.DBInstanceIdentifier}`);
                }).catch((e) => {
                    console.error(e)
                });
        } else {
            await instance.stopDBInstance({ DBInstanceIdentifier: event.DBInstanceIdentifier }).promise()
                .then(() => {
                    console.info(`Stop Instance ${event.DBInstanceIdentifier}`);
                }).catch((e) => {
                    console.error(e)
                });
        }
    } catch (error) {
        console.error('RDS StartStopDbInstance', error);

    }


}

module.exports = {
    StartStopAuroraClsuter,
    StartStopDbInstance,
    GetAllCluster,
    GetAllInstance
}