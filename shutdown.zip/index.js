const { StartStopDocdb } = require('./src/docdb');
const { StartStopEc2 } = require('./src/ec2');
const { StopStartEksNodeGroup } = require('./src/eks');
const { StartStopAuroraClsuter, StartStopDbInstance } = require('./src/rds');
const { StartStopRedshift } = require('./src/redshift');
const { StopStartECSTask } = require('./src/ecs');
const { StartStopAllResources } = require('./src/all');

exports.handler = async (event, context, callback) => {

    switch (event.type) {
        case 'ecs':
            console.log('Event ECS');
            await StopStartECSTask(event);
            break;
        case 'docdb':
            console.log('Event DocDb');
            await StartStopDocdb(event);
            break;
        case 'ec2':
            console.log('Event EC2');
            await StartStopEc2(event);
            break;
        case 'eks-node':
            console.log('Event EKS Node');
            await StopStartEksNodeGroup(event);
            break;
        case 'rds-instance':
            console.log('Event RDS Instace');
            await StartStopDbInstance(event);
            break;
        case 'rds-cluster':
            console.log('Event RDS Cluster');
            await StartStopAuroraClsuter(event);
            break;
        case 'redshift':
            console.log('Event Redshift');
            await StartStopRedshift(event);
            break;
        case 'all':
            console.log('Event All Resources');
            await StartStopAllResources(event);
            break;
        default:
            console.log('Sorry this event not exists.');
            break;
    }

}

